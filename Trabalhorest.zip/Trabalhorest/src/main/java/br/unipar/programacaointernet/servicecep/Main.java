package br.unipar.programacaointernet.servicecep;

import br.unipar.programacaointernet.servicecep.dao.UsuarioDAO;
import br.unipar.programacaointernet.servicecep.dao.UsuarioDAOImpl;
import br.unipar.programacaointernet.servicecep.model.Usuario;
import br.unipar.programacaointernet.servicecep.util.EntityManagerUtil;

public class Main {

    public static void main(String[] args) {
        try {
            EntityManagerUtil.getEntityManagerFactory();


            editarUsuario();

            EntityManagerUtil.closeEntityManagerFactory();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private static void salvarUsuario() {
        UsuarioDAO usuarioDAO = new UsuarioDAOImpl(
                EntityManagerUtil.getManager());

        Usuario usuario = new Usuario();

        usuario.setNomeUsuario("renan");
        usuario.setLoginUsuario("renanads");
        usuario.setSenhaUsuario("235456");

        usuarioDAO.save(usuario);
    }

    private static void editarUsuario() {
        UsuarioDAO usuarioDAO = new UsuarioDAOImpl(
                EntityManagerUtil.getManager());

        Usuario usuario = usuarioDAO.findById(1L);

        usuario.setSenhaUsuario("654321");

        usuarioDAO.update(usuario);
    }
}
