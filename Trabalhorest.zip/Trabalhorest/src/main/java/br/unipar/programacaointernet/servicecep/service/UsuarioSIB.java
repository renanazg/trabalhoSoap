package br.unipar.programacaointernet.servicecep.service;

public class UsuarioSIB {
}
