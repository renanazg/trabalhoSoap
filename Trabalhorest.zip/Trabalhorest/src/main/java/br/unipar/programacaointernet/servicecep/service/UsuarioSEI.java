package br.unipar.programacaointernet.servicecep.service;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;

public interface UsuarioSEI {
    @WebMethod
    String boasVindas(@WebParam(name = "nome") String nome);


    String consultaUsuario(@WebParam(NA))
}
