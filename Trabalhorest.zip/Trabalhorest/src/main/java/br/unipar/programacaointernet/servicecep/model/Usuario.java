package br.unipar.programacaointernet.servicecep.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 50)
    private String nomeUsuario;

    @Column(length = 20, nullable = false)
    private String loginUsuario;

    @Column(length = 20, nullable = false)
    private String senhaUsuario;

}
